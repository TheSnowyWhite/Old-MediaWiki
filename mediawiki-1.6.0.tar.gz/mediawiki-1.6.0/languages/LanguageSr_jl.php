<?php
/**
  * @package MediaWiki
  * @subpackage Language
  */
require_once( "LanguageSr_ec.php");

class LanguageSr_jl extends LanguageSr_ec { 
# Inherit everything for now
}
?>