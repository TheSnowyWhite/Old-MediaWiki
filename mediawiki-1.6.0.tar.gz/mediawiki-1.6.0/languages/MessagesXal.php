<?php


/* private */ $wgAllMessagesXal = array(

'edit' => 'Чиклх',
'article' => 'Халх',
'discussion' => 'Ухалвр',
'history' => 'Чикллһнə бүрткл',
'nstab-main' => 'Халх',
'nstab-user' => 'Орлцач',
'nstab-template' => 'Зура',
'nstab-help' => 'Цəəлһлһн',
'nstab-category' => 'Янз',
'talkpage' => 'Ухалвр',
'history_short' => 'Чикллһнə бүрткл',
'categories1' => 'Янз',
'category' => 'Янз',


'createaccount' => 'Выль вики-авторлэн регистрациез',
'login' => 'Оруллһн',
'mycontris' => 'Мини өгүллһдүд',
'mytalk' => 'Мини күүндлһн бəəрм',
'preferences' => 'Дурллһн',

);


?>