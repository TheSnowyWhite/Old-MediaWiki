<?php
/** Neapolitan (Nnapulitano)
  *
  * @package MediaWiki
  * @subpackage Language
  */

/** */
require_once( 'LanguageIt.php' );

/** @package MediaWiki */
class LanguageNap extends LanguageIt {
	# Inherit everything
}

?>
