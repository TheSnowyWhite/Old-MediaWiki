<?php
/** Bambara (Bamanankan)
  *
  * @package MediaWiki
  * @subpackage Language
  */

# Stub for Bambara; import French (official language of Mali)

require_once( 'LanguageFr.php' );

class LanguageBm extends LanguageFr {
	// Inherit all for now
}

?>
