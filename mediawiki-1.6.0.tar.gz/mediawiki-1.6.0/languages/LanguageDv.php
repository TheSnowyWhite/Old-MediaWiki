<?php
/** Dhivehi language file ( ދިވެހިބަސް',      )
  *
  * @package MediaWiki
  * @subpackage Language
  */

require_once( 'LanguageUtf8.php' );

class LanguageDv extends LanguageUtf8 {
	#FIXME: inherit almost everything for now

	function isRTL() {
		return true;
	}
}

?>
