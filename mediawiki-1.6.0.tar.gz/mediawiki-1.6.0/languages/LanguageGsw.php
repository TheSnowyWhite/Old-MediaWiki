<?php
/**
  * @package MediaWiki
  * @subpackage Language
  */

/*
<Melancholie> for the moment it would be the best if LanguageAls.php would be
              the same like LanguageDe.php. That would help us a lot at als.
<Melancholie> at the moment all is in English
<TimStarling> ok
<Melancholie> great
<TimStarling> I'll make a stub language file that fetches everything from de
<Melancholie> cool
*/

include_once( "LanguageDe.php" );

class LanguageGsw extends LanguageDe {
	/* Inherit everything. */
}

?>
